package com.aspireappodoo;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class odooTest1 {
	
	public WebDriver driver;
	
	@BeforeTest
	  public void beforeTest() {
		WebDriverManager.chromedriver().setup();  	
    	driver=new ChromeDriver();
    	driver.manage().timeouts().implicitlyWait(2000, TimeUnit.SECONDS);
    	driver.get("https://aspireapp.odoo.com");
    	driver.findElement(By.xpath("//input[@name='login']")).sendKeys("user@aspireapp.com");
    	driver.findElement(By.xpath("//input[@name='password']")).sendKeys("@sp1r3app");
    	driver.findElement(By.xpath("//*[contains(text(),'Log in')]")).click();
	  }	
	
	
	
	@Test(priority = 0)
	public void navigateToInventery() 
	{
		
		//driver.findElement(By.xpath("//a[@id='result_app_1']")).click();
		driver.findElement(By.xpath("//div[contains(text(),'Inventory')]")).click();
	}
	
	@Test(priority = 1)
	public void productFunctionality() 
	{
		
		driver.findElement(By.xpath("//*[contains(text(),'Products')]")).click();
    	driver.findElement(By.xpath("//header/nav[1]/ul[1]/li[3]/div[1]/a[1]")).click();
    	
    	driver.findElement(By.xpath("//*[contains(text(),'Create')]")).click();
    	
    	driver.findElement(By.xpath("//input[@name='name']")).sendKeys("testnew04");
    	
    	driver.findElement(By.xpath("//*[contains(text(),'Save')]")).click();
    	
		
	}
	
	@Test(priority = 2)
	public void updateQuantity()
	{
		//driver.findElement(By.xpath("//body/div[4]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/button[2]")).click();
    	driver.findElement(By.xpath("//span[contains(text(),'Update Quantity')]")).click();
    	
    	driver.findElement(By.xpath("//button[contains(text(),'Create')]")).click();
    	
    	driver.findElement(By.xpath("//tbody/tr[1]/td[2]/div[1]/div[1]/input[1]")).sendKeys("WH/Stock");
    	
    	driver.findElement(By.xpath("//tbody/tr[1]/td[3]/div[1]/div[1]/input[1]")).sendKeys("1");
    	
		driver.findElement(By.xpath("//input[@name='inventory_quantity']")).sendKeys("15");
		
		driver.findElement(By.xpath("//button[contains(text(),'Save')]")).click();
	}
	
	@Test(priority = 3)
	public void applicationClick() 
	{
		WebDriverWait wait = new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//header/nav[1]/a[1]")));
    	driver.findElement(By.xpath("//header/nav[1]/a[1]")).click();
	}
	
	@Test(priority = 4)
	public void manufacturingFeature() 
	{
		
    	driver.findElement(By.xpath("//a[@id='result_app_2']")).click();
    	
    	driver.findElement(By.xpath("//button[contains(text(),'Create')]")).click();
    	driver.findElement(By.xpath("//input[@id='o_field_input_1616']")).sendKeys("[1 reference] Aspire 02");
    	driver.findElement(By.xpath("//body[1]/div[4]/div[1]/div[2]/div[1]/div[1]/div[2]/div[4]/div[2]/div[1]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/a[1]")).click();
    	driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/div[1]/input[1]")).sendKeys("[1 reference] Aspire 02");
    	driver.findElement(By.xpath("//input[@name='product_uom_qty']")).sendKeys("15");
    	driver.findElement(By.xpath("//span[contains(text(),'Confirm')]")).click();
    	driver.findElement(By.xpath("//span[contains(text(),'Mark as Done')]")).click();
    	driver.switchTo().alert().accept();
    	
    	driver.findElement(By.xpath("//button[contains(text(),'Save')]")).click();
	}
  

  @AfterTest
  public void afterTest() {
	  
	  driver.close();
  }

}
